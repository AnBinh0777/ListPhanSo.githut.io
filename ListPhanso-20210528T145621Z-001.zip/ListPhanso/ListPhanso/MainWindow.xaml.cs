﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ListPhanso
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Clist b;
        CPhanso a;
        CNode c;
        public MainWindow()
        {
            InitializeComponent();
            b = new Clist();
            c = new CNode();
        }

        private void btn_nhap_Click(object sender, RoutedEventArgs e)
        {
            a = new CPhanso(int.Parse(txt_nhaptuso.Text), int.Parse(txt_nhapmauso.Text));
            b.chencuoi(a);
            txt_xuat.Text = b.xuatlist();
        }
    }
}
