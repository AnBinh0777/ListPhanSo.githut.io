﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListPhanso
{
    class CNode
    {
        private CPhanso Data; //dữ liệu của đối tượng
        private CNode Next; //giữ địa chỉ của phần tử


        public CNode()
        {
            Next = null;
        }
        public CNode (CPhanso phanso)
        {
            Data = phanso;
            Next = null;
        }
       public void taonode (CPhanso phanso)
        {
            Data = phanso;
            Next = null;
        }
       
        
        public CPhanso phanso
        {
            get
            {
                return Data;
            }
            set
            {  
                Data = value;
            }
        }
        public CNode next
        {
            get
            {
                return Next;
            }
            set
            {
                Next = value;
            }
        }
        
    }
}
