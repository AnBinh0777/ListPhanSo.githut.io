﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListPhanso
{
    class CPhanso
    {
       public int tso;
        public int mso;

        public CPhanso ()
        {
            tso = 1;
            mso = 1;
        }
        public CPhanso(int tuso, int mauso)
        {
            tso = tuso;
            mso = mauso;
        }
    }
}
