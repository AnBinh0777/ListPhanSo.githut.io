﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListPhanso
{
    
    class Clist
    {
        CNode head;
        CNode tail;
        int spt;

        public Clist()
            {
            head = tail = null;
            spt = 0;
            }
        public string xuatlist()
        {
            string s = " ";
            CNode t = head;
            while (t!= null)
            {
                s = s + t.phanso.tso + "/" + t.phanso.mso + " ";
                t = t.next;
            }
            return s;
        }
        public void chendau(CPhanso a)
        {
          CNode p = new  CNode();
            p.taonode( a );
            p = head;
            head = p;
        }
        public void chencuoi(CPhanso a)
        {
            CNode p = new CNode();
            p.taonode(a);
            if ( head == null)
            {
                head = p;
                tail = p;
            }
            else
            {
                tail.next = p;
                tail = p;
            }
            spt++;
        }
    }
}
